﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MvcProducts.Models;

namespace MvcProducts.Data
{
    public class MvcProductsContext : DbContext
    {
        public MvcProductsContext (DbContextOptions<MvcProductsContext> options)
            : base(options)
        {
        }

        public DbSet<MvcProducts.Models.Product> Product { get; set; } = default!;
    }
}
